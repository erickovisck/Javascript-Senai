window.document.write('<h1>Erick Fernando</h1>')
function rosa_muda(){
    const botao_rosa = window.document.getElementById("rosa")
    botao_rosa.style.color= "white"
    botao_rosa.style.backgroundColor= "pink"
    botao_rosa.textContent= "ROSA"
}
function vermelho_muda (){
    const botao_vermelho = window.document.getElementById("vermelho")
    botao_vermelho.style.color= "white"
    botao_vermelho.style.backgroundColor= "red"
    botao_vermelho.textContent = "VERMELHO"

}
function azul_muda (){
    const botao_azul = window.document.getElementById("azul")
    botao_azul.style.color= "white"
    botao_azul.style.backgroundColor= "blue"
    botao_azul.textContent = "AZUL"

}
function preto_muda(){
    const botao_preto = window.document.getElementById("preto")
    botao_preto.style.color= "white"
    botao_preto.style.backgroundColor= "black"
    botao_preto.textContent = "PRETO"
}